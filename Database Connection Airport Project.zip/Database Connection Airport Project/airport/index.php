<?php
	header('location: interface_layer/login.php');
?>