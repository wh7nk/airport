<!DOCTYPE html>
<html>
<head>
	<title>Airport - Home</title>
</head>
<body>
<center>

<?php 
include('masterPage.php');


				$servername = "localhost";
				$username = "root";
				$password = "";
				$dbname = "airport";
				
				$conn = new mysqli($servername, $username, $password, $dbname);
				
				if ($conn->connect_error) {
					die("Connection failed : " . $conn->connect_error);
				}
				
				// Türkçe karakter desteği
				$conn->set_charset("utf8");
				
				$sql = "SELECT ID, Name FROM airline";
				$result = $conn->query($sql);
				
				if ($result->num_rows > 0) {
				?>
				<ul>
					<?php
						while($row = $result->fetch_assoc()) {
						?>
						
						<li>
							<?php echo "id: " . $row["ID"]. ", Company Name: " . $row["Name"]; ?>
						</li>
						
						<?php
						}
					?>
				</ul>
				<?php
				} 
				else {
					echo " User not found!";
				}
				
				$conn->close();
			?>
</center>

</body>
</html>