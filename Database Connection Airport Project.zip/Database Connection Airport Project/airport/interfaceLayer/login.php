<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>

	<?php

		/*session_start();

		if(isset($_SESSION['user'])) {		
			header('location: main.php');
		}*/

	?>	



<?php 
include('masterPage.php');
 ?>
Login Page !


</body>
</html>