<!DOCTYPE html>
<html>
<head>
	<title>Airport - News</title>
</head>
<body>

<?php 
include('masterPage.php');
 ?>
News Page !


</body>
</html>