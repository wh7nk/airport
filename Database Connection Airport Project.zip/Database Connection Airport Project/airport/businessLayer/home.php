<?php
	include_once("C:/wamp64/www/airport/dataLayer/DBConnection.php");
	include_once("C:/wamp64/www/airport/businessLayer/airline.php");

	class Home{

		public static function getAllAirline() {
			$db = new DBConnection();
			$result = $db->getDataTable("SELECT id,name FROM airline");

			$allAirline =array();

			while ($row = $result->fetch_assoc()) {
				$airlineObj = new airline($row["id"],$row["name"]);

				echo "id: " . $row["id"]. ", Company Name: " . $row["name"];
				
				array_push($allAirline, $airlineObj);
			}

			return $allAirline;
		}

		public static function insertAirline($name,$detail)
		{
			$db = new DBConnection();
			$success = $db->executeQuery("INSERT INTO airline(id,name,detail) VALUES (NULL,'$name', '$detail')");
		}


	}
