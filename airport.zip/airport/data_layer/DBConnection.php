<?php
 class DB {
   private $servername = "localhost";
   private $username = "root";
   private $password = "";
   private $dbname = "airport";
   private $connection;


   function __construct() {
     $this->connection = new mysqli(
       $this->servername,
       $this->username,
       $this->password,
       $this->dbname
     );

     if($this->connection->connect_error)
     {
       die("Database Connection Error : ".$this->connection->connect_error);
     }
      $this->connection->set_charset("utf8");    
   }

   public function getConnection() {
       return $this->connection;
   }

   function __destruct() {
        $this->connection->close();
   }

   public function getDataTable($query){
        return ($this->connection->query($query) == TRUE);
   }


  }
 ?>
