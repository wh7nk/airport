<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!-- Apple devices fullscreen -->
	<meta name="apple-mobile-web-app-capable" content="yes" />
	<!-- Apple devices fullscreen -->
	<meta names="apple-mobile-web-app-status-bar-style" content="black-translucent" />
	<base href="<?=base_url()?>">

	<title>Airport - Staff</title>

	<!-- Bootstrap -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<!-- jQuery UI -->
	<link rel="stylesheet" href="assets/css/jquery-ui.min.css">
	<!-- Easy pie  -->
	<link rel="stylesheet" href="assets/css/jquery.easy-pie-chart.css">
	<!-- Theme CSS -->
	<link rel="stylesheet" href="assets/css/style.css">
	<!-- dataTables -->
	<link rel="stylesheet" href="assets/css/TableTools.css">
	<!-- chosen -->
	<link rel="stylesheet" href="assets/css/chosen.css">
	<!-- Color CSS -->
	<link rel="stylesheet" href="assets/css/themes.css">


	<!-- jQuery -->
	<script src="assets/js/jquery.min.js"></script>

	<!-- Nice Scroll -->
	<script src="assets/js/jquery.nicescroll.min.js"></script>
	<!-- imagesLoaded -->
	<script src="assets/js/jquery.imagesloaded.min.js"></script>
	<!-- jQuery UI -->
	<script src="assets/js/jquery-ui.js"></script>
	<!-- slimScroll -->
	<script src="assets/js/jquery.slimscroll.min.js"></script>
	<!-- Bootstrap -->
	<script src="assets/js/bootstrap.min.js"></script>
	<!-- Bootbox -->
	<script src="assets/js/jquery.bootbox.js"></script>
	<!-- Bootbox -->
	<script src="assets/js/jquery.form.min.js"></script>
	<!-- Validation -->
	<script src="assets/js/jquery.validate.min.js"></script>
	<script src="assets/js/additional-methods.min.js"></script>
	<!-- New DataTables -->
	<script src="assets/js/jquery.moment.min.js"></script>
	<script src="assets/js/moment-range.min.js"></script>
	<script src="assets/js/jquery.dataTables.min.js"></script>
	<script src="assets/js/dataTables.tableTools.min.js"></script>
	<script src="assets/js/dataTables.colReorder.min.js"></script>
	<script src="assets/js/dataTables.colVis.min.js"></script>
	<script src="assets/js/dataTables.scroller.min.js"></script>

	<!-- Easy pie -->
	<script src="assets/js/jquery.easy-pie-chart.min.js"></script>

	<!-- Chosen -->
	<script src="assets/js/chosen.jquery.min.js"></script>

	<!-- Theme framework -->
	<script src="assets/js/eakroko.min.js"></script>
	<!-- Theme scripts -->
	<script src="assets/js/application.min.js"></script>
	<!-- Just for demonstration -->
	<script src="assets/js/demonstration.min.js"></script>


	<!-- Favicon -->
	<link rel="shortcut icon" href="img/favicon.ico" />
	<!-- Apple devices Homescreen icon -->
	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-precomposed.png" />

</head>

<body data-layout="fixed">
	<div id="navigation">
		<div class="container-fluid">
			<a href="Staff/Index" id="brand">Staff</a>
			<a href="#" class="toggle-nav" rel="tooltip" data-placement="bottom" title="Toggle navigation">
				<i class="fa fa-bars"></i>
			</a>
			<ul class='main-nav'>
				<li>
					<a href="Staff/Index">
						<span>Index</span>
					</a>
				</li>
				<li>
					<a data-toggle="dropdown" class='dropdown-toggle'>
						<span>Arrange</span>
						<span class="caret"></span>
					</a>
					<ul class="dropdown-menu">
						<li>
							<a href="Staff/Luggage">Luggage</a>
						</li>
						<li>
							<a href="Staff/Gate">Gate</a>
						</li>
					</ul>
				</li>
			</ul>
			<div class="user">
				<ul class="icon-nav">
				</ul>
				<div class="dropdown pull-right">
					<a href="#" class='dropdown-toggle' data-toggle="dropdown"><?=$this->session->userdata('email')?>
					</a>
					<ul class="dropdown-menu pull-right">
						<li>
							<a href="more-userprofile.html">Edit My Account</a>
						</li>
						<li>
							<a href="more-login.html">Log out</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>