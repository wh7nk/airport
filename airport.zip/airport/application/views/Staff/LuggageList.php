<div class="row">
	<div class="col-sm-12">
		<div class="box box-color box-bordered">
			<div class="box-title">
				<h3>
					<i class="fa fa-table"></i>
					Gate List
				</h3>
			</div>
			<div class="box-content nopadding">
				<table class="table table-hover table-nomargin table-bordered dataTable">
					<thead>
					<tr>
						<th>Luggage Name</th>
						<th>Created At</th>
						<th>Available || Busy</th>
                        <th>Operation</th>
					</tr>
					</thead>
					<tbody>
                    <?php
                    foreach($luggage as $luggage)
                    {
                    ?>
					<tr>
						<td><?=$luggage->name?></td>
						<td><?=$luggage->created_at?></td>
						<td><?=$luggage->is_active == 0 ? "<h3 class='label-info'>Available<h3>" : "<h3 class='label-danger'>Busy</h3>";?></td>
                        <td>

						<a href="Staff/CreateLuggage" class="btn btn-primary col-sm-offset-2 btn--icon">
											<i class="glyphicon glyphicon-pencil"></i>     Create </a>

						<a href="Staff/EditLuggage/<?=$luggage->id?>" class="btn btn-default  btn--icon ">
											<i class="glyphicon glyphicon-edit"></i>     Edit </a>

						<a href="Staff_Rest/manage_luggage/<?=$luggage->id?>/<?=$luggage->is_active?>"  class="btn btn-danger btn--icon ">
											<i class="glyphicon glyphicon-remove"></i>     Activate/Disable </a>				
						</td>
					</tr>

                    <?php
                    }
                    ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<script>
	$(document).ready(function()
	{
		$('#create-gate-form').submit(function()
		{
			$.ajax({
            type: 'POST',
            url: 'Staff_Rest/create_gate', 
            data: $(this).serialize()
        })
        .done(function(data)
		{
             $("#gate_created").html('<button type="button" class="close" data-dismiss="alert">×</button><h5 class="col-md-offset-1"><strong>Gate is successfully created.</strong></h5>').show();
        })
        .fail(function(data)
		{
		   alert("busy");
        });
 
        // to prevent refreshing the whole page page
        return false;
 
    });
});
</script>