<div class="row">
					<div class="col-sm-5 col-md-offset-4">
						<div class="box box-bordered">
							<div class="box-title">
								<h3>
									<i class="fa fa-th-list"></i>Create Gate</h3>
							</div>
							<div class="box-content nopadding">
								<form role="form" class='form-validate form-horizontal form-striped' id="create-gate-form">
									<div class="form-group">
										<label for="new_gate_name" class="control-label col-sm-2">Gate Name : </label>
										<div class="col-sm-10">
											<input type="text" name="new_gate_name" id="new_gate_name" placeholder="Gate Name" class="form-control" data-rule-required="true">
										</div>
									</div>
									<div class="form-actions col-sm-offset-2 col-sm-10">
										<input type="submit" value="Create Gate" class='btn btn-primary pull-left col-xs-6 col-sm-7 col-sm-offset-3'>
                                         <div id ="gate_found" class="alert alert-danger alert-dismissable" style="display:none; margin-top:50px;"></div>
                                          <div id ="gate_created" class="alert alert-success alert-dismissable" style="display:none; margin-top:50px;"></div>
                                    </div>
								</form>
							</div>
						</div>
					</div>
				</div>
                
	<script>
	$(document).ready(function()
	{
		$('#create-gate-form').submit(function()
		{
			$.ajax({
            type: 'POST',
            url: 'Staff_Rest/create_gate', 
            data: $(this).serialize()
        })
        .done(function(data)
		{
             $("#gate_created").html('<button type="button" class="close" data-dismiss="alert">×</button><h5 class="col-md-offset-1"><strong>Gate is successfully created.</strong></h5>').show();
        })
        .fail(function()
		{
            $("#gate_found").html('<button type="button" class="close" data-dismiss="alert">×</button><h5 class="col-md-offset-1"><strong>Gate is already created.</strong></h5>').show();
        });
 
        // to prevent refreshing the whole page page
        return false;
 
    });
});
</script>