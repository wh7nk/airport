<div id="main">
			<div class="container-fluid">
				<div class="page-header">
					<div class="pull-left">
						<h1>Welcome  <h3 class='col-md-offset-4 col-sm-7'><?=$this->session->userdata('email')?></h3></h1>
					</div>
					<div class="pull-right">						
						<ul class="stats">
							<li class='lightred'>
								<i class="fa fa-calendar"></i>
								<div class="details">
									<span class="big">Time : <?=date("Y-m-d H:i:s")?></span>
								</div>
							</li>
						</ul>
					</div>
				</div>
				<div class="breadcrumbs">
					<ul>
						<li>
							<a>Index</a>
							<i class="fa fa-angle-right"></i>
						</li>
						<li>
							<a>Welcome</a>
							<i class="fa fa-angle-right"></i>
						</li>
					</ul>
					<div class="close-bread">
						<a href="#">
							<i class="fa fa-times"></i>
						</a>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<div class="box">
							<div class="box-title">
								<h3>
									<i class="fa fa-bars"></i>
									Role : Staff Member
								</h3>
							</div>
							<div class="row">
							<div class="col-sm-12">
							<div class="box-content">
								<ul class="tiles tiles-center nomargin">
									<li class="lightgrey has-chart">
										<a>
											<span>
												<div class="chart easyPieChart" data-percent="<?=$gate_counter?>" data-color="#ffffff" data-trackcolor="#333333" style="line-height: 120px;"><?=$gate_counter?>%<canvas height="150" width="120"></canvas></div>
											</span>
											<span class="name"># of Gates</span>
										</a>
									</li>
									<li class="lightred has-chart">
										<a>
											<span>
												<div class="chart easyPieChart" data-percent="<?=$luggage_counter?>" data-color="#ffffff" data-trackcolor="#f96d6d" style="line-height: 150px;"><?=$luggage_counter?>%<canvas height="250" width="200"></canvas></div>
											</span>
											<span class="name col-sm-2" style="margin-top : 10px;"># of Luggage</span>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
						
						</div>
					</div>
				</div>
			</div>
		</div>