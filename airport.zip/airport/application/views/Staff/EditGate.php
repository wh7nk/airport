<div class="row">
					<div class="col-sm-5 col-md-offset-4">
						<div class="box box-bordered">
							<div class="box-title">
								<h3>
									<i class="fa fa-th-list"></i>Edit Gate</h3>
							</div>
							<div class="box-content nopadding">
								<form role="form" class='form-validate form-horizontal form-striped' id="create-gate-form">
									<?php
                                     foreach($gate as $row)
                                    {
                                    ?>
                                    <div class="form-group">
										<label for="new_gate_name" class="control-label col-sm-2">Gate Name : </label>
										<div class="col-sm-10">
											<input type="text" name="gate_name" id="gate_name" placeholder="Gate Name" value="<?=$row->name?>" class="form-control" data-rule-required="true">
										</div>
									</div>
                                   <input type="hidden" id="row_name" name="row_name" value="<?=$row->id?>">
									<div class="form-actions col-sm-offset-2 col-sm-7" style="margin-top:5px;" >
										<input type="submit" value="Edit Gate" class='btn btn-default pull-left col-xs-6 col-sm-7 col-sm-offset-3'>
                                         <div id ="gate_found" class="alert alert-danger alert-dismissable" style="display:none; margin-top:50px;"></div>
                                          <div id ="gate_updated" class="alert alert-success alert-dismissable" style="display:none; margin-top:50px;"></div>
                                    </div>
                                    <?php
                                    }
                                    ?>
								</form>
							</div>
						</div>
					</div>
				</div>
                
	<script>
	$(document).ready(function()
	{
		$('#create-gate-form').submit(function()
		{
			$.ajax({
            type: 'POST',
            url: 'Staff_Rest/edit_gate', 
            data: $(this).serialize()
        })
        .done(function(data)
		{
             $("#gate_updated").html('<button type="button" class="close" data-dismiss="alert">×</button><h5 class="col-md-offset-1"><strong>Gate is successfully updated.</strong></h5>').show();
        })
        .fail(function()
		{
            $("#gate_found").html('<button type="button" class="close" data-dismiss="alert">×</button><h5 class="col-md-offset-1"><strong>Gate is already created.</strong></h5>').show();
            window.setTimeout( function(){
                 window.location = "Staff/Gate";
             }, 2000 );
        });
        return false;
 
    });
});
</script>