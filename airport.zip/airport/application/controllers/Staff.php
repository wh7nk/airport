<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Staff extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();        	
        $this->load->library("CSRFToken_Generator");
	}
	public function Index()
	{
		if($this->session->userdata('logged_in') == 1)
		{
			$this->load->model("Gates");
			$this->load->model("Luggage");
			$data["gate_counter"] = $this->Gates->count_gates();
			$data["luggage_counter"] = $this->Luggage->count_luggage();
			$this->load->view('includes/StaffHeader');
			$this->load->view('Staff/Index',$data);
			$this->load->view('includes/StaffFooter');
		}
		else
		{
			redirect('Staff/Login', 'refresh');
		}
	}
	public function Gate()
	{
		$this->load->model("Gates");
		//container array
		$data["gates"] = $this->Gates->get_gates();		
		$this->load->view('includes/StaffHeader');
		//php compact'ten geliyor -> view
		$this->load->view("Staff/GateList",$data);
		$this->load->view('includes/StaffFooter');
	}
	
	public function Luggage()
	{
		$this->load->model("Luggage");
		//container array
		$data["luggage"] = $this->Luggage->get_luggage();		
		$this->load->view('includes/StaffHeader');
		$this->load->view("Staff/LuggageList",$data);
		$this->load->view('includes/StaffFooter');
	}

	public function test()
	{
		//XSS filter
		$k = $this->input->post('',true);
	}
	
	public function test2()
	{
		print_r($this->session->all_userdata());
	}
	public function Login()
	{
		$this->csrftoken_generator->generate_csrf();
		$this->load->view('Staff/Login');
	}

	public function Logout()
	{
		$this->csrftoken_generator->generate_csrf();
		$this->load->view('Staff/Logout');
	}

	public function CreateGate()
	{
			$this->load->view('includes/StaffHeader');
			$this->load->view('Staff/CreateGate');
			$this->load->view('includes/StaffFooter');
	}

	public function EditGate()
	{
		$this->load->Model("Gates");
		$gate_id = (int) $this->uri->segment(3);
		$data["gate"] = $this->Gates->find_gate_by_id($gate_id);
		$this->load->view('includes/StaffHeader');
		$this->load->view('Staff/EditGate',$data);
		$this->load->view('includes/StaffFooter');
	}

	public function CreateLuggage()
	{
			$this->load->view('includes/StaffHeader');
			$this->load->view('Staff/CreateLuggage');
			$this->load->view('includes/StaffFooter');
	}
	
	public function EditLuggage()
	{
		$this->load->Model("Luggage");
		$luggage_id = (int) $this->uri->segment(3);
		$data["luggage"] = $this->Luggage->find_luggage_by_id($luggage_id);
		$this->load->view('includes/StaffHeader');
		$this->load->view('Staff/EditLuggage',$data);
		$this->load->view('includes/StaffFooter');
	}
}
