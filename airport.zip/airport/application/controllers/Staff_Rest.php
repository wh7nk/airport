<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Staff_Rest extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();        	
        $this->load->library("CSRFToken_Generator");
	}
	public function do_login()
	{
		$this->load->model("Staff");
		$email = $this->input->post("email",true);//xss protection
		$password = $this->input->post("password",true);	
		$csrf_token = $this->input->post("airport_csrf_token",true);			
		$is_staff_found = $this->Staff->validate_staff($email, $this->encrypt_password_with_sha1($password));

		if($this->csrftoken_generator->validate_csrf_token($csrf_token))
        {
        	if($is_staff_found == true)
        		$this->return_success_for_entity($email);
        	else
        		$this->return_entity_is_not_found();
		}
		else
		{
			return $this->output
				->set_content_type('application/json')
            	->set_status_header(403)
            	->set_output(json_encode(array(
                   'invalid_token' => $this->csrftoken_generator->validate_csrf_token($csrf_token))));
		}
	}
	public function return_success_for_entity($email)
	{
		$this->set_my_session($this->init_my_session($email));
				return $this->output
            	->set_content_type('application/json')
            	->set_status_header(200)
            	->set_output(json_encode(array(
                    'status' => 'found'
            	)));
	}
	public function return_entity_is_not_found()
	{
		return $this->output
				->set_content_type('application/json')
            	->set_status_header(422)
            	->set_output(json_encode(array(
                   'status' => 'not_found'
            )));
	}
	
	public function init_my_session($email)
	{
		return $session_array = array(
        'email'     => $email,
        'logged_in' => TRUE);		
	}
	
	public function set_my_session($session_array)
	{
		$this->session->set_userdata($session_array);
	}
	
	public function encrypt_password_with_sha1($password)
	{
		return sha1($password."f5327844a992e6e88891fcdc6f4832a650f450afb01d3814d937e6286a0b");
	}

	public function create_gate()
	{
		$this->load->model("Gates");
		$gate_name =  $this->input->post("new_gate_name",true);
		if(!$this->Gates->is_gate_existent($gate_name))
		{
			$this->return_gate_is_found();
		}
		else
		{
			$gate_array = array('name' => $gate_name);
			$this->Gates->create_gate($gate_array);
			$this->return_gate_created();
		}
	}
	public function return_gate_is_found()
	{
		return $this->output
				->set_content_type('application/json')
            	->set_status_header(400)
            	->set_output(json_encode(array(
                   'success' => false
            )));
	}
	public function return_gate_created()
	{
		return $this->output
            	->set_content_type('application/json')
            	->set_status_header(200)
            	->set_output(json_encode(array(
                    'success' => true
            	)));
	}
	public function manage_gate()
	{
		$this->load->model("Gates");
		$gate_id =  (int) $this->uri->segment(3);
		$is_active = (int) $this->uri->segment(4) == 0 ? 1 : 0;
		$gate = array('id' => $gate_id,
					  'is_active' => $is_active);
		if(!$this->Gates->is_gate_busy($gate_id))
		{
			$this->Gates->manage_gate($gate);
			Redirect('Staff/Gate', 'refresh');
		}
		else
		{		
			Redirect('Staff/Gate', 'refresh');
			$this->return_gate_busy();
		}
	}
	public function edit_gate()
	{
		$this->load->model("Gates");
		$edit_gate_name = $this->input->post("gate_name",true);
		if(!$this->Gates->is_gate_existent($edit_gate_name))
		{
			$this->return_gate_is_found();
		}
		else
		{
			$gate = array('id' => (int)$this->input->post("row_name",true),
					  'name' => $edit_gate_name );
			$this->Gates->manage_gate($gate);
			$this->return_gate_edited();
		}
	}
	public function return_gate_edited()
	{
		return $this->output
            	->set_content_type('application/json')
            	->set_status_header(200)
            	->set_output(json_encode(array(
                    'success' => true
            	)));
	}


	public function return_gate_busy()
	{
		echo "busy";
		/*return $this->output
            	->set_content_type('application/json')
            	->set_status_header(400)
            	->set_output(json_encode(array(
                    'busy' => true
            	)));*/
	}

	public function create_luggage()
	{
		$this->load->model("Luggage");
		$luggage_name =  $this->input->post("new_luggage_name",true);
		if(!$this->Luggage->is_luggage_existent($luggage_name))
		{
			$this->return_luggage_is_found();
		}
		else
		{
			$luggage_array = array('name' => $luggage_name);
			$this->Luggage->create_luggage($luggage_array);
			$this->return_luggage_created();
		}
	}
	public function return_luggage_is_found()
	{
		return $this->output
				->set_content_type('application/json')
            	->set_status_header(400)
            	->set_output(json_encode(array(
                   'success' => false
            )));
	}
	public function return_luggage_created()
	{
		return $this->output
            	->set_content_type('application/json')
            	->set_status_header(200)
            	->set_output(json_encode(array(
                    'success' => true
            	)));
	}
	public function manage_luggage()
	{
		$this->load->model("Luggage");
		$luggage_id =  (int) $this->uri->segment(3);
		$is_active = (int) $this->uri->segment(4) == 0 ? 1 : 0;
		$luggage = array('id' => $luggage_id,
					  'is_active' => $is_active);
		if(!$this->Luggage->is_luggage_busy($luggage_id))
		{
			$this->Luggage->manage_luggage($luggage);
			Redirect('Staff/Luggage', 'refresh');
		}
		else
		{		
			Redirect('Staff/Luggage', 'refresh');
			$this->return_luggage_busy();
		}
	}
	public function edit_luggage()
	{
		$this->load->model("Luggage");
		$edit_luggage_name = $this->input->post("luggage_name",true);
		if(!$this->Luggage->is_luggage_existent($edit_luggage_name))
		{
			$this->return_luggage_is_found();
		}
		else
		{
			$luggage = array('id' => (int)$this->input->post("row_name",true),
					  'name' => $edit_luggage_name );
			$this->Luggage->manage_luggage($luggage);
			$this->return_luggage_edited();
		}
	}
	public function return_luggage_edited()
	{
		return $this->output
            	->set_content_type('application/json')
            	->set_status_header(200)
            	->set_output(json_encode(array(
                    'success' => true
            	)));
	}


	public function return_luggage_busy()
	{
		echo "busy";
		/*return $this->output
            	->set_content_type('application/json')
            	->set_status_header(400)
            	->set_output(json_encode(array(
                    'busy' => true
            	)));*/
	}

}