<?php
class Gates extends CI_Model
{
	public function get_gates()
	{
        $sql = $this->db->query("select g.* from gates g");
	 	foreach ($sql->result() as $row) 
	 	{
	 		$gate_rows[] = $row;
        }
        return $gate_rows;
    } 

    public function count_gates()
    {
        return $this->db->count_all('gates');
    }

    public function find_gate_by_id($gate_id)
    {       
        $sql = $this->db->query("select g.* from gates g where g.id = ? ",array($gate_id));
        foreach ($sql->result() as $row) 
        {
            $gate_array[] = $row;
        }
        return $gate_array;
    }
    
    public function is_gate_existent($gate_name)
    {
       $sql = $this->db->query("select count(*) as gateFound from gates g where g.name = ?", array($gate_name));
      	foreach ($sql->result() as $row) 
       {
           $gate_found = $row->gateFound;
       }
       return $gate_found == 1 ? false : true;
    }

    public function is_gate_busy($gate_id)
    {
        $sql = $this->db->query("select count(*) as gateBusy from companygatemapping cg where cg.gate_id = ?", array($gate_id));
      	foreach ($sql->result() as $row) 
       {
           $gate_busy = $row->gateBusy;
       }
       return $gate_busy == 1 ? true : false;
    }

    public function create_gate($gate_array)
    {       
        $this->db->insert('gates', $gate_array); 
    }

    public function manage_gate($gate)
    {
       $this->db->where('id', $gate["id"]);
	   $this->db->update('gates', $gate);
    }
}
