<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Staff extends CI_Model
{
	public function validate_staff($email, $password)
	{
		$entity_found = 0;
		$stmt ='select count(*) as isEntityValid from staff s where s.email = ? and s.password = ?';
		$query=$this->db->query($stmt, array($email,$password));
		foreach ($query->result() as $row)
		{
			$entity_found = $row->isEntityValid;
		}
		return $entity_found == 1 ? true : false;
	}
}
