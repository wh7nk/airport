<?php
class Luggage extends CI_Model
{
    public function get_luggage()
	{
     $sql = $this->db->query("select l.* from luggage l");
	 	foreach ($sql->result() as $row) 
	 	{
	 		$luggage_rows[] = $row;
        }
        return $luggage_rows;
    }

    public function count_luggage()
    {
      return $this->db->count_all('luggage');
    }
    
    public function find_luggage_by_id($luggage_id)
    {       
        $sql = $this->db->query("select l.* from luggage l where l.id = ? ",array($luggage_id));
        foreach ($sql->result() as $row) 
        {
            $luggage_array[] = $row;
        }
        return $luggage_array;
    }

     public function is_luggage_existent($luggage_name)
    {
       $sql = $this->db->query("select count(*) as luggageFound from luggage l where l.name = ?", array($luggage_name));
      	foreach ($sql->result() as $row) 
       {
           $luggage_found = $row->luggageFound;
       }
       return $luggage_found == 1 ? false : true;
    }

    public function is_luggage_busy($luggage_id)
    {
        $sql = $this->db->query("select count(*) as luggageBusy from companygatemapping cg where cg.luggage_id = ?", array($luggage_id));
      	foreach ($sql->result() as $row) 
       {
           $luggage_busy = $row->luggageBusy;
       }
       return $luggage_busy == 1 ? true : false;
    }

 public function create_luggage($luggage_array)
    {       
        $this->db->insert('luggage', $luggage_array); 
    }
    
    public function manage_luggage($luggage)
    {
       $this->db->where('id', $luggage["id"]);
	   $this->db->update('luggage', $luggage);
    }
}
?>