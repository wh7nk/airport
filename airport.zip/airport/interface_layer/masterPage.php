<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Airport</title>


  <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Cherry+Swash'>

      <link rel="stylesheet" href="css/style2.css">


</head>

<body>
  <h1>Airport Gate Operation</h1>

<nav>
 	 <a href="home.php">Home</a>
 	 <a href="news.php">News</a>
 	 <a href="about.php">About</a>
 	 <a href="contact.php">Contact</a>
 	 <a href="login.php">Login</a>
	<div class="animation start-home"></div>
</nav>

<p>
  © Copyright <span>Emrah EMREM & Aslıhan Gürkan</span>
</p>


</body>
</html>
