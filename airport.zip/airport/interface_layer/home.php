<!DOCTYPE html>
<html>
<head>
	<title>Airport - Home</title>
</head>
<body>

<?php 
include('masterPage.php');
 ?>
Home Page !


</body>
</html>